import './style.css';
import { lerJsonLd, lerMicrodados, lerRdfa, lerMetaSociais, contarLandmarks } from './semantica.js';

// 1) Marca o link do menu da página atual com aria-current="page"
const paginaAtual = location.pathname.split('/').pop() || 'index.html';
document.querySelectorAll('nav[aria-label="Menu principal"] a').forEach((link) => {
  const destino = link.getAttribute('href').replace('/', '');
  if (destino === paginaAtual) link.setAttribute('aria-current', 'page');
});

// 2) Formulário de compra: avisa leitores de tela pela região role="status"
const form = document.querySelector('form.compra');
if (form) {
  form.addEventListener('submit', (evento) => {
    evento.preventDefault();
    const qtd = form.quantidade.value;
    const moagem = form.moagem.value;
    form.querySelector('.status').textContent = `${qtd} pacote(s) “${moagem}” adicionado(s) ao carrinho.`;
  });
}

// 3) Inspetor de web semântica: mostra o que uma máquina "enxerga" na página
function bloco(titulo, descricao, dados) {
  const secao = document.createElement('section');
  const h3 = document.createElement('h3');
  h3.textContent = titulo;
  const p = document.createElement('p');
  p.textContent = descricao;
  const pre = document.createElement('pre');
  pre.textContent = JSON.stringify(dados, null, 2);
  secao.append(h3, p, pre);
  return secao;
}

const botao = document.createElement('button');
botao.className = 'inspetor-botao';
botao.type = 'button';
botao.textContent = '{ } Ver dados semânticos';
botao.setAttribute('aria-haspopup', 'dialog');

const dialogo = document.createElement('dialog');
dialogo.className = 'inspetor';
dialogo.setAttribute('aria-labelledby', 'titulo-inspetor');

botao.addEventListener('click', () => {
  dialogo.replaceChildren();
  const topo = document.createElement('header');
  const h2 = document.createElement('h2');
  h2.id = 'titulo-inspetor';
  h2.textContent = 'Dados semânticos desta página';
  const fechar = document.createElement('button');
  fechar.type = 'button';
  fechar.textContent = 'Fechar';
  fechar.addEventListener('click', () => dialogo.close());
  topo.append(h2, fechar);

  dialogo.append(
    topo,
    bloco('Schema.org em JSON-LD', 'Blocos <script type="application/ld+json"> no <head>.', lerJsonLd()),
    bloco('Microdados', 'Atributos itemscope, itemtype e itemprop no próprio HTML.', lerMicrodados()),
    bloco('RDFa', 'Atributos vocab, typeof e property.', lerRdfa()),
    bloco('Open Graph e Twitter Cards', 'Metatags usadas pelas redes sociais ao compartilhar o link.', lerMetaSociais()),
    bloco('Elementos semânticos do HTML5', 'Quantidade de cada elemento estrutural na página.', contarLandmarks()),
  );
  dialogo.showModal();
});

document.body.append(botao, dialogo);
