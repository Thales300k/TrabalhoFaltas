// Funções que LEEM os dados semânticos da página atual.
// Elas mostram, na prática, que as marcações são legíveis por máquina.

/** Lê todos os blocos <script type="application/ld+json"> */
export function lerJsonLd(doc = document) {
  return [...doc.querySelectorAll('script[type="application/ld+json"]')].map((s) => {
    try {
      return JSON.parse(s.textContent);
    } catch (erro) {
      return { erro: 'JSON-LD inválido', detalhe: erro.message };
    }
  });
}

/** Lê o valor de um elemento com itemprop, conforme a especificação de Microdados */
function valorMicrodado(el) {
  if (el.hasAttribute('itemscope')) return lerItem(el);
  if (el.tagName === 'META') return el.getAttribute('content');
  if (['A', 'LINK'].includes(el.tagName)) return el.getAttribute('href');
  if (['IMG', 'AUDIO', 'VIDEO', 'SOURCE'].includes(el.tagName)) return el.getAttribute('src');
  if (el.tagName === 'DATA' || el.tagName === 'METER') return el.getAttribute('value');
  if (el.tagName === 'TIME') return el.getAttribute('datetime') ?? el.textContent.trim();
  return el.textContent.trim();
}

/** Monta um objeto a partir de um elemento com itemscope */
function lerItem(escopo) {
  const item = { '@type': escopo.getAttribute('itemtype')?.replace('https://schema.org/', '') };
  // Propriedades que pertencem a este escopo (e não a um escopo filho)
  const props = [...escopo.querySelectorAll('[itemprop]')].filter(
    (el) => el.parentElement.closest('[itemscope]') === escopo,
  );
  for (const el of props) {
    const nome = el.getAttribute('itemprop');
    const valor = valorMicrodado(el);
    if (nome in item) item[nome] = [].concat(item[nome], valor);
    else item[nome] = valor;
  }
  return item;
}

/** Lê os itens de Microdados de nível mais alto da página */
export function lerMicrodados(doc = document) {
  return [...doc.querySelectorAll('[itemscope]:not([itemprop])')].map(lerItem);
}

/** Leitura simplificada de RDFa (typeof / property) */
function lerRecurso(el) {
  const recurso = { '@type': el.getAttribute('typeof') };
  const id = el.getAttribute('resource') ?? el.getAttribute('href');
  if (id) recurso['@id'] = id;
  const props = [...el.querySelectorAll('[property]')].filter(
    (p) => p.parentElement.closest('[typeof]') === el,
  );
  for (const p of props) {
    const nome = p.getAttribute('property');
    let valor;
    if (p.hasAttribute('typeof')) valor = lerRecurso(p);
    else if (p.hasAttribute('content')) valor = p.getAttribute('content');
    else if (p.hasAttribute('href')) valor = p.getAttribute('href');
    else valor = p.textContent.trim();
    if (nome in recurso) recurso[nome] = [].concat(recurso[nome], valor);
    else recurso[nome] = valor;
  }
  return recurso;
}

export function lerRdfa(doc = document) {
  return [...doc.querySelectorAll('[vocab][typeof]')].map(lerRecurso);
}

/** Lê as metatags Open Graph, Twitter e de artigo/produto */
export function lerMetaSociais(doc = document) {
  const saida = {};
  const seletor = 'meta[property^="og:"], meta[property^="article:"], meta[property^="product:"], meta[name^="twitter:"]';
  doc.querySelectorAll(seletor).forEach((m) => {
    saida[m.getAttribute('property') ?? m.getAttribute('name')] = m.getAttribute('content');
  });
  return saida;
}

/** Conta os elementos estruturais (landmarks) do HTML5 */
export function contarLandmarks(doc = document) {
  const tags = ['header', 'nav', 'main', 'article', 'section', 'aside', 'footer', 'figure', 'time', 'address'];
  return Object.fromEntries(tags.map((t) => [t, doc.querySelectorAll(t).length]));
}
