import { resolve } from 'node:path';
import { defineConfig } from 'vite';

// Projeto com várias páginas HTML: cada uma é uma entrada do build.
export default defineConfig({
  base: './',
  build: {
    rollupOptions: {
      input: {
        main: resolve(import.meta.dirname, 'index.html'),
        produto: resolve(import.meta.dirname, 'produto.html'),
        blog: resolve(import.meta.dirname, 'blog.html'),
      },
    },
  },
});
